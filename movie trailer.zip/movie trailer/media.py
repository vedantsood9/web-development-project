import webbrowser
import fresh_tomatoes

		

class Movie() :

	def __init__(self,movie_title,movie_storyline,poster_image,trailer_youtube):
	
		self.title = movie_title
		self.storyline = movie_storyline
		self.poster_image_url = poster_image
		self.trailer_youtube_url = trailer_youtube
 
	def show_trailer(self):
		webbrowser.open(self.trailer_youtube_url)

def open_movies_page(Movie):
  # Create or overwrite the output file
  output_file = open('fresh_tomatoes.html', 'w')

  # Replace the placeholder for the movie tiles with the actual dynamically generated content
  rendered_content = main_page_content.format(movie_tiles=create_movie_tiles_content(movies))

  # Output the file
  output_file.write(main_page_head + rendered_content)
  output_file.close()

  # open the output file in the browser
  url = os.path.abspath(output_file.name)
  webbrowser.open('file://' + url, new=2) 
