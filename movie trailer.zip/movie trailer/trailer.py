import fresh_tomatoes
import media
import webbrowser

indie = media.Movie("Indie playlist","Indie rock is a genre of alternative rock","https://apionline.sodapdf.com/Public/widgets/convertmyimage/download/1.png","https://www.youtube.com/watch?v=76Wygb_Aqz0")
print(indie.storyline)
#indie.show_trailer()

acoustic = media.Movie("Acostic playlist","ACostic playlist is a type of music","https://apionline.sodapdf.com/Public/widgets/convertmyimage/download/2.png","https://www.youtube.com/watch?v=RAVESsJXLa8")
print(acoustic.storyline)


halsey = media.Movie("Halsey song","Halsey music","https://apionline.sodapdf.com/Public/widgets/convertmyimage/download/3.png","https://www.youtube.com/watch?v=-cPp6WMKVjA")
print(halsey.storyline)

bad_liar = media.Movie("Bad liar","music of Selena gomez","https://apionline.sodapdf.com/Public/widgets/convertmyimage/download/4.png","https://www.youtube.com/watch?v=NZKXkD6EgBk")
print(bad_liar.storyline)

movies = [indie,acoustic,halsey,bad_liar]
fresh_tomatoes.open_movies_page(movies)


