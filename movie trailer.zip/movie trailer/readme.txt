.Python need to be installed in any OS to run this program.
.Run trailer.py with IDE or in terminal with command
                                             'python trailer.py' 
.After we execute our program,a page in browser will be opened ,where we can
 select and play any trailer.